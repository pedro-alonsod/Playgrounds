If you updated the code for a more recent Swift toolchain, did you remember to also update the "Latest toolchain tested" date on the first page of the playground? That would be rad.

Thank you so much!
