//
//  Person+CoreDataClass.swift
//  HitList
//
//  Created by Luke Parham on 12/23/16.
//  Copyright © 2016 Razeware. All rights reserved.
//

import Foundation
import CoreData


public class Person: NSManagedObject {

}
