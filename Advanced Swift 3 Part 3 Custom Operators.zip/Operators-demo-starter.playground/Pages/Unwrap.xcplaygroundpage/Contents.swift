// Copyright (c) 2017 Razeware LLC
// See Copyright Notice page for details about the license.

var emptyValue: Int? = nil
var fullValue: Int? = 10

// let value = fullValue !! fatalError("no value when one was expected")
