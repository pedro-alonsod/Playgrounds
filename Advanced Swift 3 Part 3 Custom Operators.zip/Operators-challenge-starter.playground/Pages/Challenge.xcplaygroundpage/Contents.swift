// Copyright (c) 2017 Razeware LLC
// See Copyright Notice page for details about the license.


// Create an operator +/- that enables the following test case.

/*
let aboutThree = 3.0 +/- 0.5   // Create a Range(2.5..<3.5)
aboutThree.contains(2.7)
 */
