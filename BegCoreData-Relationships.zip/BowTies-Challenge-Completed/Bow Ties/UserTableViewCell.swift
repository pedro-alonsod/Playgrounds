//
//  UserCollectionViewCell.swift
//  Bow Ties
//
//  Created by Luke Parham on 10/30/16.
//  Copyright © 2016 Razeware. All rights reserved.
//

import UIKit

class UserTableViewCell: UITableViewCell {
  
  @IBOutlet weak var nameLabel: UILabel!
}
