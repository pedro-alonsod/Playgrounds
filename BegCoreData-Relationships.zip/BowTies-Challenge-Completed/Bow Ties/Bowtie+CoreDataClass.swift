//
//  Bowtie+CoreDataClass.swift
//  Bow Ties
//
//  Created by Luke Parham on 10/30/16.
//  Copyright © 2016 Razeware. All rights reserved.
//

import Foundation
import CoreData


public class Bowtie: NSManagedObject {

}
