//
//  User+CoreDataClass.swift
//  Bow Ties
//
//  Created by Luke Parham on 1/5/17.
//  Copyright © 2017 Razeware. All rights reserved.
//

import Foundation
import CoreData


public class User: NSManagedObject {

}
