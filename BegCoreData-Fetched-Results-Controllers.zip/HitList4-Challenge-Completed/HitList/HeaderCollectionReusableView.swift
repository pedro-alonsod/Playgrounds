//
//  HeaderCollectionReusableView.swift
//  HitList
//
//  Created by Luke Parham on 10/27/16.
//  Copyright © 2016 Razeware. All rights reserved.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {
  @IBOutlet weak var headerLabel: UILabel!
        
}
